<div class="row">
	<div class="col-lg-12">
		<!-- page statustic card start -->
		<div class="card table-card review-card">
			<div class="card-body p-4">
				<div class="table-responsive">
					<table class="table table-hover table-card text-center" id="table">
						<thead>
							<tr>
								<th scope="col">No</th>
								<th scope="col">Kelembaban</th>
								<th scope="col">Suhu</th>
								<th scope="col">Intensitas Cahaya</th>
								<th scope="col">PH</th>
								<th scope="col">Created</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th scope="row">1</th>
								<td>2</td>
								<td>4</td>
								<td>5</td>
								<td>5</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<!-- page statustic card end -->
	</div>
</div>
