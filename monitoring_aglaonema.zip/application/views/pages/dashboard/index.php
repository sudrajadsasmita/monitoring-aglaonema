<div class="row">
	<div class="col-lg-12">
		<!-- page statustic card start -->
		<div class="card table-card review-card">
			<div class="card-body p-4">
				<div class="card">
					<h3 class="text-center text-primary text-uppercase">Monitoring Tanaman Aglaonema</h3>
					<lottie-player src="https://assets1.lottiefiles.com/packages/lf20_k6yuvgny.json" class="mx-auto mt-3" background="transparent" speed="1" style="width: 300px; height: 300px;" loop autoplay></lottie-player>
					<a href="<?= site_url('Monitoring'); ?>" class="btn btn-primary mt-3">Get Started</a>
				</div>
			</div>
		</div>
		<!-- page statustic card end -->
	</div>
</div>
