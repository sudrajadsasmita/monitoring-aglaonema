<li class="nav-item pcoded-menu-caption">
	<label>Navigation</label>
</li>
<li class="nav-item">
	<a href="<?= site_url(); ?>" class="nav-link "><span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Dashboard</span></a>
</li>
<li class="nav-item">
	<a href="<?= site_url('Monitoring') ?>" class="nav-link "><span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Monitoring</span></a>
</li>
